
import './App.css';
import WeatherWidget from "./WeitherWidget/index";


function App() {
  return (
    <div className="App">

      <WeatherWidget />

    </div>
  );
}

export default App;
