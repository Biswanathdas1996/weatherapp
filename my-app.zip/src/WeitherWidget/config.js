
require('dotenv').config();


export const API_KEY = process.env.REACT_APP_WEATHER_API_KEY;

export const BASE_API_URL = process.env.REACT_APP_BASE_API_URL;

export const BASE_IMG_URL = process.env.REACT_APP_BASE_IMG_URL;


